

public class clockDriver {

	public static void main(String[] args) {
		Clock myClock=new Clock();
		Clock yourClock=new Clock(3,4,5);

	}

}
