
public class TryA {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("TryA message");
		System.out.println("TryB message");

	}

}
