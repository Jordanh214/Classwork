
public class clockJH {
//instance variables 
	private int hr;
	private int min;
	private int sec;
	
//Constructor Method (Overloaded)
	public clock()
	{
		hr=0;
		min=0;
		sec=0;
	}
	
	public Clock(int hours, int minutes, int seconds)
	{
		hr=hours;
		min=minutes;
		sec=seconds;
	}
}
