
public class ClassworkSep26 {
	String critName;
	String critMood;
	
	
	public ClassworkSep26(String name)
	{
		critName=name;
	}
	
	public ClassworkSep26(String name, String mood)
	{
		critName=name;
		critMood=mood;
	}
	
	public String toString()
	{
		
		return critName;
	
	}
}
